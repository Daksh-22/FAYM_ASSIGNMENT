"""
Batch vs. Sequential flow detection.

The assignment spec (section 2) says the agent must "detect which model
applies" per order. The obvious shortcut is to ask an LLM to look at the
page and guess. I deliberately didn't do that: flow model is a property of
the *platform's* return API/UI, not something that should vary run to run
or depend on an LLM being available. Making this a deterministic lookup
means:
  1. It's free (no token cost, no latency, no LLM flakiness).
  2. It's testable with a plain unit test, no mocking a browser or an API.
  3. It's auditable: a reviewer can read one dict and know exactly how the
     agent will behave for every platform, instead of trusting a model call.

If a platform's behavior genuinely varies per order (e.g. some flipkart
categories batch, others don't), that's still better modeled as an explicit
rule here than as a live inference, because the rule can be encoded once
we see the counter-example, and it never regresses silently.
"""

from core.models import FlowModel

# Per assignment brief section 2: "Batch flow (e.g. Amazon) - one return flow
# can cover all items in the order" and "Sequential flow (e.g. Amazon,
# Flipkart) - the agent repeats the return micro-flow once per line item."
# Amazon is listed under both, meaning Amazon's own behavior is order-dependent
# (some Amazon orders batch, some don't) while Flipkart is always sequential.
PLATFORM_DEFAULT_FLOW = {
    "flipkart": FlowModel.SEQUENTIAL,
}

# Amazon-specific rule: a single-seller, single-shipment order can usually be
# returned in one batch flow; a multi-seller or split-shipment order cannot,
# because each shipment has its own return micro-flow. This is the one place
# where "how many line items" alone isn't enough, so amazon gets its own rule.
def _amazon_flow_model(order_line_items: list) -> FlowModel:
    distinct_sellers = {li.get("seller_id") for li in order_line_items if li.get("seller_id")}
    distinct_shipments = {li.get("shipment_id") for li in order_line_items if li.get("shipment_id")}
    if len(distinct_sellers) <= 1 and len(distinct_shipments) <= 1:
        return FlowModel.BATCH
    return FlowModel.SEQUENTIAL


def detect_flow_model(platform: str, order_line_items: list) -> FlowModel:
    """
    order_line_items: list of dicts, one per SKU on the order, each optionally
    carrying seller_id / shipment_id metadata scraped from the order details
    page. Only Amazon needs that metadata; Flipkart is a fixed rule.
    """
    platform = platform.strip().lower()
    if platform == "amazon":
        return _amazon_flow_model(order_line_items)
    if platform in PLATFORM_DEFAULT_FLOW:
        return PLATFORM_DEFAULT_FLOW[platform]
    # Unknown platform: default to the safer assumption (process one at a
    # time) rather than risk silently skipping items in an unverified batch flow.
    return FlowModel.SEQUENTIAL
