"""
Core data model for the returns automation agent.

Design choice: everything the agent reasons about (a return, its state,
its outcome) is a typed dataclass, not a raw Excel row or a dict. This
means the orchestrator, adapters, and Excel writer all share one
unambiguous contract, and unit tests can construct a ReturnTask without
touching Excel or a browser at all.
"""

from dataclasses import dataclass, field
from datetime import datetime, date
from enum import Enum
from typing import Optional


class ReturnStatus(str, Enum):
    """Outcome of the return attempt itself, as reported by the platform."""
    PLACED = "Placed"
    FAILED = "Failed"
    OUT_OF_WINDOW = "Out of window"
    NOT_ATTEMPTED = "Not attempted"


class TaskStatus(str, Enum):
    """
    Workflow status of the line item, distinct from ReturnStatus.

    A task can be "Done" with a ReturnStatus of OUT_OF_WINDOW (we correctly
    determined it was ineligible and closed it out) or "Needs human review"
    with a ReturnStatus of FAILED (the platform rejected it for a reason we
    didn't anticipate, and a human should look at it rather than the agent
    silently retrying forever).
    """
    TO_DO = "To Do"
    IN_PROGRESS = "In Progress"
    DONE = "Done"
    NEEDS_REVIEW = "Needs human review"


class FlowModel(str, Enum):
    """Which return micro-flow this platform/order combination requires."""
    BATCH = "batch"          # one flow can cover every line item in the order
    SEQUENTIAL = "sequential"  # the micro-flow must repeat once per line item


@dataclass
class ReturnTask:
    """One row = one line item (one SKU on one order). Matches the Excel
    schema in the assignment spec section 4 field-for-field."""

    row_index: int                       # Excel row number, for write-back
    platform: str                        # "Amazon" | "Flipkart"
    order_id: str
    product_sku: str
    return_window_end: Optional[date]    # last day this item can be returned
    return_reason: str = "Not needed"    # default reason if not specified

    # Fields the agent fills in as it runs:
    task_status: TaskStatus = TaskStatus.TO_DO
    return_status: ReturnStatus = ReturnStatus.NOT_ATTEMPTED
    return_id: Optional[str] = None
    refund_amount: Optional[float] = None
    attempts: int = 0
    last_error: Optional[str] = None
    timestamp: Optional[datetime] = None

    def is_eligible(self, as_of: Optional[date] = None) -> bool:
        """Pure function, no browser required. Runs before we ever open a
        page, so ineligible items never cost us a browser session."""
        as_of = as_of or date.today()
        if self.return_window_end is None:
            return True  # unknown window: let the platform be the judge
        return as_of <= self.return_window_end

    def mark_terminal(self, return_status: ReturnStatus, *, return_id: str = None,
                       refund_amount: float = None, error: str = None):
        self.return_status = return_status
        self.return_id = return_id
        self.refund_amount = refund_amount
        self.last_error = error
        self.timestamp = datetime.now()
        self.task_status = (
            TaskStatus.DONE if return_status in (ReturnStatus.PLACED, ReturnStatus.OUT_OF_WINDOW)
            else TaskStatus.NEEDS_REVIEW
        )


@dataclass
class OrderGroup:
    """All line items belonging to one OrderID, plus the detected flow model.
    The orchestrator processes items *within* a group independently (section 5,
    partial-success handling) but only reports the order fully Done when every
    item in the group has a terminal task_status."""
    order_id: str
    platform: str
    flow_model: FlowModel
    tasks: list = field(default_factory=list)

    @property
    def is_fully_done(self) -> bool:
        return all(t.task_status in (TaskStatus.DONE, TaskStatus.NEEDS_REVIEW) for t in self.tasks)

    @property
    def summary(self) -> dict:
        return {
            "order_id": self.order_id,
            "platform": self.platform,
            "flow_model": self.flow_model.value,
            "total_items": len(self.tasks),
            "placed": sum(1 for t in self.tasks if t.return_status == ReturnStatus.PLACED),
            "out_of_window": sum(1 for t in self.tasks if t.return_status == ReturnStatus.OUT_OF_WINDOW),
            "needs_review": sum(1 for t in self.tasks if t.task_status == TaskStatus.NEEDS_REVIEW),
        }
