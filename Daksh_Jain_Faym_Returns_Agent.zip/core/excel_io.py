"""
Excel I/O, matching the assignment's field table (section 4) exactly.

Column contract:
  Platform            | input, pre-filled
  Order ID            | input, pre-filled
  Product / SKU        | input, pre-filled
  Return window        | input / verified
  Return reason         | input, pre-filled (what reason to select on the platform)
  Return ID            | written by agent
  Return status         | written by agent
  Refund amount          | written by agent
  Task status            | written by agent
  Timestamp / log         | written by agent

Design choice: every write-back is scoped to a single row (openpyxl cell
writes), not a full-sheet overwrite. That matters because the agent may be
re-run after a partial failure (crash, network drop mid-run); re-reading the
sheet and only touching rows still in "To Do" / "In Progress" means we never
clobber a row another process already finished, and a re-run is safe to do
by default rather than something the operator has to reason about.
"""

from datetime import datetime, date
from pathlib import Path
from typing import List

import openpyxl

from core.models import ReturnTask, TaskStatus, ReturnStatus

COLUMNS = [
    "Platform", "Order ID", "Product/SKU", "Return window", "Return reason",
    "Return ID", "Return status", "Refund amount", "Task status", "Timestamp/log",
]


def _parse_date(value) -> date:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return datetime.strptime(str(value), "%Y-%m-%d").date()


def load_pending_tasks(xlsx_path: str, sheet_name: str = "Returns") -> List[ReturnTask]:
    """Reads only rows whose Task status is 'To Do' or 'In Progress' (a
    prior run may have left something mid-flight after a crash). Rows
    already 'Done' or 'Needs human review' are left untouched, so a re-run
    is idempotent by construction rather than by convention."""
    wb = openpyxl.load_workbook(xlsx_path)
    ws = wb[sheet_name] if sheet_name in wb.sheetnames else wb.active

    header = [c.value for c in ws[1]]
    col_idx = {name: header.index(name) + 1 for name in COLUMNS if name in header}

    tasks = []
    for row in ws.iter_rows(min_row=2):
        row_index = row[0].row
        status_cell = row[col_idx["Task status"] - 1].value if "Task status" in col_idx else None
        if status_cell not in (None, "", TaskStatus.TO_DO.value, TaskStatus.IN_PROGRESS.value):
            continue  # already terminal, skip

        def get(col):
            return row[col_idx[col] - 1].value if col in col_idx else None

        task = ReturnTask(
            row_index=row_index,
            platform=str(get("Platform") or "").strip(),
            order_id=str(get("Order ID") or "").strip(),
            product_sku=str(get("Product/SKU") or "").strip(),
            return_window_end=_parse_date(get("Return window")),
            return_reason=str(get("Return reason") or "Not needed"),
        )
        if task.platform and task.order_id:
            tasks.append(task)
    wb.close()
    return tasks


def write_task_result(xlsx_path: str, task: ReturnTask, sheet_name: str = "Returns"):
    """Writes back exactly one row. Opens, edits, saves; called once per
    completed task rather than batched, so a crash after item 3 of 5 has
    already persisted items 1 to 3 to disk."""
    wb = openpyxl.load_workbook(xlsx_path)
    ws = wb[sheet_name] if sheet_name in wb.sheetnames else wb.active
    header = [c.value for c in ws[1]]
    col_idx = {name: header.index(name) + 1 for name in COLUMNS if name in header}

    r = task.row_index
    ws.cell(row=r, column=col_idx["Return ID"], value=task.return_id or "")
    ws.cell(row=r, column=col_idx["Return status"], value=task.return_status.value)
    ws.cell(row=r, column=col_idx["Refund amount"], value=task.refund_amount or "")
    ws.cell(row=r, column=col_idx["Task status"], value=task.task_status.value)
    log_note = task.last_error or "OK"
    ts = (task.timestamp or datetime.now()).strftime("%Y-%m-%d %H:%M:%S")
    ws.cell(row=r, column=col_idx["Timestamp/log"], value=f"{ts} | {log_note}")

    wb.save(xlsx_path)
    wb.close()


def build_sample_workbook(path: str, rows: list):
    """Builds a demo Excel file with the exact required schema, used by
    --demo mode so the agent is runnable and reviewable without a live
    platform login."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Returns"
    ws.append(COLUMNS)
    for row in rows:
        ws.append(row)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
