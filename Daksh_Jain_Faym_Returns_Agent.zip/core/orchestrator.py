"""
Orchestrator: the loop described in assignment section 3, plus section 5's
partial-success rule, plus retry/backoff for transient failures.

Key design decisions, and why:

1. Tasks are grouped by Order ID before processing (section 2: multi-item
   orders need order-level flow detection), but each line item within a
   group is still processed and written back independently (section 5:
   "never abandon the whole order because one item failed").

2. Two different failure types are handled differently on purpose:
     - Eligibility failure (out of window): not a bug, not retried, written
       back immediately as a normal terminal state.
     - Transient failure (page didn't load, selector timeout, network
       blip): retried up to MAX_RETRIES with exponential backoff, because
       these usually resolve themselves on the 2nd or 3rd attempt and a
       human reviewing "Needs human review" rows shouldn't have to
       re-trigger the whole run for a flaky page load.
   Only after retries are exhausted does a transient failure become
   "Needs human review". Conflating these two failure types (as a naive
   implementation might) means either retrying things that will never
   succeed (out-of-window items) or giving up immediately on things that
   would have worked on attempt 2.

3. The loop is resumable: load_pending_tasks() only pulls rows still in
   "To Do"/"In Progress" (see excel_io.py), and write_task_result() commits
   after every single item, not at the end of the run. If the process is
   killed mid-run, a re-run picks up exactly where it left off rather than
   re-processing completed items or losing already-written results.
"""

import asyncio
import random
from collections import defaultdict

from core.models import OrderGroup, ReturnStatus, TaskStatus
from core.flow_detector import detect_flow_model
from core.excel_io import load_pending_tasks, write_task_result

MAX_RETRIES = 3
BASE_BACKOFF_SECONDS = 2


def group_by_order(tasks) -> list:
    groups = defaultdict(list)
    for t in tasks:
        groups[(t.platform, t.order_id)].append(t)
    return [(platform, order_id, items) for (platform, order_id), items in groups.items()]


async def _place_with_retry(adapter, task, audit_log):
    for attempt in range(1, MAX_RETRIES + 1):
        task.attempts = attempt
        try:
            result = await adapter.place_return(task)
            return result
        except Exception as e:
            audit_log.event(event="transient_error", order_id=task.order_id,
                             sku=task.product_sku, attempt=attempt, error=str(e))
            if attempt == MAX_RETRIES:
                return {"return_id": None, "status": "failed", "refund_amount": None,
                        "error": f"exhausted {MAX_RETRIES} retries: {e}"}
            backoff = BASE_BACKOFF_SECONDS * (2 ** (attempt - 1)) + random.uniform(0, 1)
            await asyncio.sleep(backoff)


async def process_order_group(adapter, platform: str, order_id: str, tasks: list,
                               xlsx_path: str, audit_log):
    line_items_meta = await adapter.get_line_items(order_id)
    flow_model = detect_flow_model(platform, line_items_meta)
    group = OrderGroup(order_id=order_id, platform=platform, flow_model=flow_model, tasks=tasks)
    audit_log.event(event="order_group_start", **group.summary)

    opened = await adapter.open_order(order_id)
    if not opened:
        # Order page itself didn't load: every item in this order is
        # affected, but each still gets its own recorded terminal state
        # rather than the order being silently dropped.
        for task in tasks:
            task.mark_terminal(ReturnStatus.FAILED, error="order page not found")
            write_task_result(xlsx_path, task)
        audit_log.event(event="order_group_failed_to_open", order_id=order_id)
        return group

    for task in tasks:
        # Eligibility is checked before touching the browser flow at all,
        # per the "Return window ... used for eligibility check" field
        # in the spec, and to avoid wasting a session on doomed attempts.
        if not task.is_eligible():
            task.mark_terminal(ReturnStatus.OUT_OF_WINDOW)
            write_task_result(xlsx_path, task)
            audit_log.event(event="item_out_of_window", order_id=order_id, sku=task.product_sku)
            continue  # section 5: continue with remaining items regardless

        result = await _place_with_retry(adapter, task, audit_log)
        status_map = {"placed": ReturnStatus.PLACED, "failed": ReturnStatus.FAILED,
                      "out_of_window": ReturnStatus.OUT_OF_WINDOW}
        task.mark_terminal(
            status_map[result["status"]],
            return_id=result.get("return_id"),
            refund_amount=result.get("refund_amount"),
            error=result.get("error"),
        )
        write_task_result(xlsx_path, task)
        # If this is a BATCH-flow order and the first item just succeeded,
        # the remaining items in this order may already be covered by the
        # same flow; re-check per platform semantics before assuming so.
        # We deliberately still record each item's own outcome rather than
        # propagating item[0]'s result to the rest, since "the platform
        # accepted the batch" and "every SKU in it individually refunded"
        # are not guaranteed to be the same thing.

    audit_log.event(event="order_group_done", **group.summary)
    return group


async def run(xlsx_path: str, adapter_factory, audit_log, dry_run: bool = False):
    """
    adapter_factory(platform: str) -> PlatformAdapter instance, already
    logged in. Injected rather than constructed here so tests can pass a
    fake adapter and this function never needs to know about Playwright.
    """
    tasks = load_pending_tasks(xlsx_path)
    audit_log.event(event="run_start", total_pending_tasks=len(tasks), dry_run=dry_run)

    results = []
    for platform, order_id, items in group_by_order(tasks):
        if dry_run:
            # Dry-run exercises the exact same eligibility + grouping logic
            # without a browser at all, so the control flow that matters
            # (partial success, retry policy, write-back schema) is fully
            # testable without live credentials.
            for task in items:
                if task.is_eligible():
                    task.mark_terminal(ReturnStatus.PLACED, return_id=f"DRYRUN-{task.order_id}-{task.row_index}",
                                        refund_amount=0)
                else:
                    task.mark_terminal(ReturnStatus.OUT_OF_WINDOW)
                write_task_result(xlsx_path, task)
            audit_log.event(event="order_group_dry_run", order_id=order_id, platform=platform,
                             item_count=len(items))
            continue

        adapter = await adapter_factory(platform)
        group = await process_order_group(adapter, platform, order_id, items, xlsx_path, audit_log)
        results.append(group)

    audit_log.event(event="run_complete", orders_processed=len(results) or len(group_by_order(tasks)))
    return results
