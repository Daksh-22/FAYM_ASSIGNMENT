"""
Structured audit logging, kept separate from the Excel write-back.

Why this exists: Excel tells you the *outcome* (Placed / Failed / Out of
window). It doesn't tell you *why* the agent made each decision, how many
retries it took, or what the page actually looked like when something
failed. For an agent that is allowed to act on a live e-commerce account,
that trail matters as much as the outcome, both for debugging failures and
for being able to show, after the fact, exactly what the agent did and why.
This is a product-thinking addition as much as an engineering one: an
operator reviewing "Needs human review" rows needs enough context to act
on them without re-running the whole thing.
"""

import json
from datetime import datetime
from pathlib import Path


class AuditLog:
    def __init__(self, log_dir: str = "logs"):
        Path(log_dir).mkdir(parents=True, exist_ok=True)
        self.path = Path(log_dir) / f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jsonl"
        self._fh = open(self.path, "a", encoding="utf-8")

    def event(self, **fields):
        fields["ts"] = datetime.now().isoformat()
        self._fh.write(json.dumps(fields, default=str) + "\n")
        self._fh.flush()

    def close(self):
        self._fh.close()
