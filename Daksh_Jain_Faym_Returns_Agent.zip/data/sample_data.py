"""
Synthetic sample rows for --demo mode. Deliberately includes:
  - a single-item order (simplest case)
  - a multi-item order where every item is eligible (partial success N/A)
  - a multi-item order where ONE item is past its return window and the
    others are not, to exercise the exact scenario the spec calls out in
    section 5 ("place returns for A and B even if C fails")
  - one Amazon order and two Flipkart orders, to exercise both adapters
    and both flow models
"""

from datetime import date, timedelta

TODAY = date.today()
FUTURE = (TODAY + timedelta(days=10)).isoformat()
PAST = (TODAY - timedelta(days=5)).isoformat()

SAMPLE_ROWS = [
    # Platform, Order ID, Product/SKU, Return window, Return reason, (blank agent columns...)
    ["Flipkart", "OD1001", "SKU-BLENDER-01", FUTURE, "Defective", "", "", "", "", ""],

    ["Amazon", "AMZ2002", "SKU-SHOES-BLK-9", FUTURE, "Wrong size", "", "", "", "", ""],
    ["Amazon", "AMZ2002", "SKU-SHOES-BLK-10", FUTURE, "Wrong size", "", "", "", "", ""],

    ["Flipkart", "OD1003", "SKU-PHONE-CASE-A", FUTURE, "Not as described", "", "", "", "", ""],
    ["Flipkart", "OD1003", "SKU-SCREEN-GUARD", PAST, "Not as described", "", "", "", "", ""],  # out of window
    ["Flipkart", "OD1003", "SKU-CHARGER-C", FUTURE, "Not as described", "", "", "", "", ""],
]
