"""
Flipkart adapter. Flow model is always SEQUENTIAL per the assignment brief
(section 2), so this adapter never batches items; place_return() is called
once per line item by the orchestrator.

Selectors are loaded from config/selectors.yaml rather than hardcoded, see
that file's header comment for why. These specific selectors are written
against Flipkart's typical DOM structure as of assignment time; they are
NOT guaranteed to match the live site today; Flipkart, like any retail
site, changes markup on a normal release cadence, and the assignment
brief's login flow (OTP via a phone call to a specific number) makes truly
live end-to-end verification a manual, one-off action rather than
something this script can prove automatically. Validate against the config
before a live run; if a selector is stale, this file does not need to
change, only config/selectors.yaml does.
"""

from adapters.base import PlatformAdapter
from core.stealth import humanized_click, humanized_type, humanized_delay
from core.models import ReturnTask


class FlipkartAdapter(PlatformAdapter):
    name = "flipkart"

    def __init__(self, page, humanizer, audit_log, selectors: dict):
        super().__init__(page, humanizer, audit_log)
        self.sel = selectors["flipkart"]

    async def login(self, credentials: dict) -> bool:
        phone = credentials["phone"]
        await self.page.goto("https://www.flipkart.com/account/login")
        await humanized_type(self.page.locator(self.sel["login_phone_input"]), phone)
        await humanized_click(self.page, self.page.locator(self.sel["request_otp_button"]))
        self.audit_log.event(event="otp_requested", platform="flipkart", phone=phone)

        # OTP is delivered by a phone call per the brief ("Request OTP by
        # calling ..."), not SMS, so it cannot be scraped from the page or
        # an inbox. This is the one step that genuinely requires a human
        # in the loop; the agent pauses and waits for it rather than
        # guessing or looping indefinitely.
        otp = await self._await_human_otp_entry()
        await humanized_type(self.page.locator(self.sel["otp_input"]), otp)
        await humanized_click(self.page, self.page.locator(self.sel["submit_otp_button"]))
        await humanized_delay()
        return "logout" in (await self.page.content()).lower()

    async def _await_human_otp_entry(self) -> str:
        # In a real run this would be an input() prompt on the console
        # (see main.py's --live path) or a small local webhook a human
        # posts to after the phone call. Kept as its own method so it is
        # the single obvious seam to swap in whatever OTP-delivery
        # mechanism the operator prefers, without touching login() itself.
        raise NotImplementedError("Wire this to console input() or a webhook in main.py for a live run.")

    async def open_order(self, order_id: str) -> bool:
        await self.page.goto(f"https://www.flipkart.com/account/orders/{order_id}")
        await humanized_delay()
        return order_id in (await self.page.content())

    async def get_line_items(self, order_id: str) -> list:
        # Flipkart is always sequential (see flow_detector.PLATFORM_DEFAULT_FLOW),
        # so seller/shipment metadata isn't needed for flow detection here;
        # this still returns SKUs for logging/audit completeness.
        rows = self.page.locator("div[class*='order-item-row']")
        count = await rows.count()
        items = []
        for i in range(count):
            sku_text = await rows.nth(i).inner_text()
            items.append({"sku": sku_text.strip()})
        return items

    async def place_return(self, task: ReturnTask) -> dict:
        if not task.is_eligible():
            # Never opens the return flow for an ineligible item; the
            # eligibility check already ran before this method was called
            # (see orchestrator.py), this is a defensive second check.
            return {"return_id": None, "status": "out_of_window", "refund_amount": None, "error": None}

        try:
            await humanized_click(self.page, self.page.locator(self.sel["return_replace_button"]))
            reasons = self.page.locator(self.sel["return_reason_list"])
            await humanized_click(self.page, reasons.filter(has_text=task.return_reason).first)
            await humanized_click(self.page, self.page.locator(self.sel["refund_option_radio"]).first)
            await humanized_click(self.page, self.page.locator(self.sel["confirm_return_button"]))
            await humanized_delay()

            return_id = (await self.page.locator(self.sel["return_id_text"]).inner_text()).strip()
            refund_text = (await self.page.locator(self.sel["refund_amount_text"]).inner_text()).strip()
            refund_amount = float("".join(c for c in refund_text if c.isdigit() or c == "."))

            self.audit_log.event(event="return_placed", platform="flipkart",
                                  order_id=task.order_id, sku=task.product_sku, return_id=return_id)
            return {"return_id": return_id, "status": "placed", "refund_amount": refund_amount, "error": None}

        except Exception as e:
            self.audit_log.event(event="return_failed", platform="flipkart",
                                  order_id=task.order_id, sku=task.product_sku, error=str(e))
            return {"return_id": None, "status": "failed", "refund_amount": None, "error": str(e)}
