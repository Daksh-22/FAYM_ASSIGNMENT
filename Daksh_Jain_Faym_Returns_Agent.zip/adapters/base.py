"""
Platform adapter interface.

Every e-commerce site needs the same four capabilities from this agent's
point of view (log in, find the order, place the return, read back the
result), even though the actual selectors and click paths differ
completely between Amazon and Flipkart. Encoding that as an abstract base
class means:
  - the orchestrator never contains an if/elif on platform name;
  - adding a third platform (e.g. Myntra) means writing one new adapter
    file, not touching orchestrator or Excel logic;
  - each adapter can be unit-tested against a saved HTML fixture without
    the others, and without a live browser.

This is the single biggest structural difference from a monolithic
agent.py: platform-specific fragility (which is guaranteed here, retail
sites change their DOM constantly) stays contained to one file per
platform instead of leaking into shared control flow.
"""

from abc import ABC, abstractmethod
from typing import Optional

from core.models import ReturnTask


class PlatformAdapter(ABC):
    name: str

    def __init__(self, page, humanizer, audit_log):
        self.page = page
        self.humanizer = humanizer   # see stealth.py: human-like delays/movement
        self.audit_log = audit_log

    @abstractmethod
    async def login(self, credentials: dict) -> bool:
        """Returns True once an authenticated session is confirmed present."""

    @abstractmethod
    async def open_order(self, order_id: str) -> bool:
        """Navigates to the order details page. Returns False if not found."""

    @abstractmethod
    async def get_line_items(self, order_id: str) -> list:
        """Returns [{'sku':..., 'seller_id':..., 'shipment_id':...}, ...]
        scraped from the order page, used by flow_detector for Amazon."""

    @abstractmethod
    async def place_return(self, task: ReturnTask) -> dict:
        """
        Runs the actual return micro-flow for one line item.
        Must return a dict with keys: return_id, status ('placed'|'failed'|
        'out_of_window'), refund_amount, error (None on success).
        Must never raise for an *expected* ineligibility (out of window);
        that's a normal outcome, not an exception. Only raise for genuinely
        unexpected states (page didn't load, selector not found), which the
        orchestrator will catch and retry with backoff.
        """
