"""
Amazon adapter. Unlike Flipkart, Amazon's flow model is order-dependent
(single-seller/single-shipment orders can batch; split-shipment or
multi-seller orders cannot), so this adapter's get_line_items() also
returns seller_id/shipment_id, which flow_detector.detect_flow_model()
uses to decide batch vs. sequential per order.

Same caveat as flipkart.py applies: selectors here are representative of
Amazon's typical order/returns DOM structure, not verified against a live
session in this environment. See config/selectors.yaml for the single
place to update them.
"""

from adapters.base import PlatformAdapter
from core.stealth import humanized_click, humanized_type, humanized_delay
from core.models import ReturnTask


class AmazonAdapter(PlatformAdapter):
    name = "amazon"

    def __init__(self, page, humanizer, audit_log, selectors: dict):
        super().__init__(page, humanizer, audit_log)
        self.sel = selectors["amazon"]

    async def login(self, credentials: dict) -> bool:
        await self.page.goto("https://www.amazon.in/ap/signin")
        await humanized_type(self.page.locator(self.sel["login_email_input"]), credentials["email"])
        await humanized_click(self.page, self.page.locator(self.sel["login_continue_button"]))
        await humanized_type(self.page.locator(self.sel["login_password_input"]), credentials["password"])
        await humanized_click(self.page, self.page.locator(self.sel["login_submit_button"]))
        await humanized_delay()
        return "sign out" in (await self.page.content()).lower()

    async def open_order(self, order_id: str) -> bool:
        await self.page.goto(f"https://www.amazon.in/gp/your-account/order-details?orderID={order_id}")
        await humanized_delay()
        return order_id in (await self.page.content())

    async def get_line_items(self, order_id: str) -> list:
        rows = self.page.locator(self.sel["order_row"])
        count = await rows.count()
        items = []
        for i in range(count):
            row = rows.nth(i)
            sku_text = await row.inner_text()
            seller_id = await row.get_attribute("data-seller-id")
            shipment_id = await row.get_attribute("data-shipment-id")
            items.append({"sku": sku_text.strip(), "seller_id": seller_id, "shipment_id": shipment_id})
        return items

    async def place_return(self, task: ReturnTask) -> dict:
        if not task.is_eligible():
            return {"return_id": None, "status": "out_of_window", "refund_amount": None, "error": None}

        try:
            await humanized_click(self.page, self.page.locator(self.sel["return_replace_link"]))
            item_box = self.page.locator(self.sel["item_checkbox"]).filter(has_text=task.product_sku)
            await humanized_click(self.page, item_box.first)
            await self.page.locator(self.sel["reason_dropdown"]).select_option(label=task.return_reason)
            await humanized_click(self.page, self.page.locator(self.sel["refund_method_radio"]).first)
            await humanized_click(self.page, self.page.locator(self.sel["confirm_return_button"]))
            await humanized_delay()

            return_id = (await self.page.locator(self.sel["return_id_text"]).inner_text()).strip()
            refund_text = (await self.page.locator(self.sel["refund_amount_text"]).inner_text()).strip()
            refund_amount = float("".join(c for c in refund_text if c.isdigit() or c == "."))

            self.audit_log.event(event="return_placed", platform="amazon",
                                  order_id=task.order_id, sku=task.product_sku, return_id=return_id)
            return {"return_id": return_id, "status": "placed", "refund_amount": refund_amount, "error": None}

        except Exception as e:
            self.audit_log.event(event="return_failed", platform="amazon",
                                  order_id=task.order_id, sku=task.product_sku, error=str(e))
            return {"return_id": None, "status": "failed", "refund_amount": None, "error": str(e)}
