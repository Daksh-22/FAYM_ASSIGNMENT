# Design Rationale

This document is here because I'm applying for a product role, not a pure
engineering one, and the code alone doesn't show how I thought about the
problem before writing it. This is that thinking.

## 1. What is this agent actually for?

Reading the brief again with a product lens rather than an engineering one:
this isn't "automate clicking return buttons." It's a reliability and trust
problem wearing an automation costume. The agent is being handed write
access to real orders on real e-commerce accounts. A slow agent is an annoyance. An agent that silently does the wrong thing
and goes unnoticed until a customer or a finance team member asks where a
refund went is a much bigger problem, and that's the failure mode every
design choice below is trying to prevent. Every design choice below optimizes to make that outcome impossible, sometimes at the cost of raw
speed or code brevity.

## 2. Requirements traceability

Mapping every line of the brief to a concrete decision, so nothing was
quietly dropped:

| Brief requirement | Where it's implemented | Why this way |
|---|---|---|
| Read pending tasks from Excel | `excel_io.load_pending_tasks` | Only pulls "To Do"/"In Progress" rows, so re-runs are safe by default |
| Detect batch vs. sequential | `flow_detector.detect_flow_model` | Deterministic rule, not an LLM guess (see §4) |
| Write back per line item | `excel_io.write_task_result` | One row, one write, called immediately after each outcome |
| Never abandon an order over one failed item | `orchestrator.process_order_group` | Loop continues on `continue`, not exception; unit-tested directly |
| Flag ineligible items, don't drop them | `ReturnTask.is_eligible` + `mark_terminal` | Recorded as `Out of window` / `Done`, a real terminal state, not a silent skip |
| Only mark order Done when every item has a final state | `OrderGroup.is_fully_done` | Explicit property, checked by the audit log summary |
| Avoid bot detection | `core/stealth.py` | Fingerprint patch + human-like timing/typing/mouse movement (see §5) |

## 3. The one requirement I pushed back on, mentally

"Must run without getting flagged or blocked by the platforms as a bot" is
phrased as a hard requirement. It can't actually be satisfied with
certainty; no client-side technique defeats a platform's server-side
detection with confidence, and claiming otherwise would be the kind of
overconfident answer I'd want a PM on my team to flag rather than paper
over. So I treated it as "reduce detection risk with the techniques that matter
most and are best understood" rather than "solve bot detection", and said so
directly in the README instead of implying a guarantee I can't back up.

## 4. Why flow detection is a rule, not a model call

The obvious approach (and the one the public reference solution takes) is
to have an LLM look at the order page and infer batch vs. sequential. I
didn't do that, for a reason that matters more in production than in a
demo: **flow model is a property of the platform's UI, not something that
should be allowed to vary.** If an LLM call ever misclassifies a batch-flow
order as sequential, the agent would re-run the return micro-flow multiple
times against what the platform expects to see once, an error class that's
invisible until it produces a duplicate return or a rejected second
attempt. A deterministic lookup can be wrong too, but it's wrong the same
way every time, which means it's debuggable and unit-testable in a way a
model call sampled at inference time is not. I'd rather ship a rule that's
occasionally incomplete (and gets a new case added when discovered) than a
model call that's occasionally and unpredictably wrong.

## 5. Why two failure types are handled differently

An "out of window" result and a "the page timed out" result are both
technically failures, but treating them the same way is the single easiest
mistake to make in a spec like this. If you retry an out-of-window item,
you waste time and risk the platform flagging repeated identical requests
as suspicious. If you give up immediately on a timeout, you turn a routine
network blip into a false "Needs human review", which defeats the entire
point of automating this in the first place, an operator now has to
manually review something that would have succeeded on attempt two. The
orchestrator checks eligibility first (no retry, immediate terminal state)
and only applies retry/backoff to genuinely unexpected failures.

## 6. What I would build next, given more time

- **A dashboard, not just a JSONL log.** The audit log is the right raw
  data, but a PM would want a daily view of: return volume, success rate by
  platform, top failure reasons, and average time-to-resolution. That's a
  half-day build on top of what already exists.
- **A confidence-scored selector health check** that runs before a live
  batch, hitting each platform's order page and confirming every selector
  in `config/selectors.yaml` still resolves, so a broken selector is caught
  before 50 orders fail, not after.
- **Rate limiting tied to account age/order volume**, not just per-order
  delay, since a brand-new low-activity account attempting 50 returns in
  an hour is a different risk profile than an established account doing
  the same volume.

## 7. What I did not do, and why

I did not attempt a fully verified live run against real Amazon/Flipkart
accounts in this environment. The Flipkart login requires a phone call to
receive an OTP, which is a real-world, human-in-the-loop step by design,
and Amazon credentials weren't provided for a test account. Claiming a
verified live run without either would be the wrong kind of confident. The
`--demo` and `--dry-run` modes exercise every piece of control-flow logic
(grouping, eligibility, retries, partial success, write-back schema)
without needing either, which is as far as I can honestly take this without
live access.
