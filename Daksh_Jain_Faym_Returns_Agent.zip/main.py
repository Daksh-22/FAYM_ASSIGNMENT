"""
Entrypoint. Three modes, matching how you'd actually want to validate an
agent like this before trusting it with a real account:

  --demo      builds a fresh sample Excel (data/sample_returns.xlsx) with a
              mix of eligible, out-of-window, and multi-item orders, then
              runs in dry-run mode against it. No browser, no login,
              nothing external. This is the fastest way to see the
              partial-success and eligibility logic actually work.

  --dry-run   runs against an existing Excel file the same way, still no
              browser. Useful once you have real order data but aren't
              ready to touch a live account yet.

  --live      launches Playwright, logs in for real, and drives the actual
              site. Requires credentials in .env. Flipkart login needs a
              human to read the OTP off a phone call and enter it when
              prompted, that step cannot be automated per the assignment's
              own login method, so this mode pauses for console input at
              that point rather than pretending it can bypass it.
"""

import argparse
import asyncio
import os

from dotenv import load_dotenv

from core.audit_log import AuditLog
from core.excel_io import build_sample_workbook
from core import orchestrator
from data.sample_data import SAMPLE_ROWS

DEFAULT_XLSX = "data/returns.xlsx"


async def _live_adapter_factory(selectors: dict, audit_log: AuditLog):
    from playwright.async_api import async_playwright
    from core.stealth import new_stealth_context
    from adapters.flipkart import FlipkartAdapter
    from adapters.amazon import AmazonAdapter

    playwright = await async_playwright().start()
    browser = await playwright.chromium.launch(headless=False)  # headful: less bot-like by default
    context = await new_stealth_context(browser, user_data_dir=".browser_profile")
    page = await context.new_page()

    async def factory(platform: str):
        platform = platform.strip().lower()
        if platform == "flipkart":
            adapter = FlipkartAdapter(page, humanizer=None, audit_log=audit_log, selectors=selectors)
            await adapter.login({"phone": os.environ["FLIPKART_PHONE"]})
            return adapter
        elif platform == "amazon":
            adapter = AmazonAdapter(page, humanizer=None, audit_log=audit_log, selectors=selectors)
            await adapter.login({"email": os.environ["AMAZON_EMAIL"], "password": os.environ["AMAZON_PASSWORD"]})
            return adapter
        raise ValueError(f"No adapter for platform: {platform}")

    return factory


def _load_selectors() -> dict:
    import yaml
    with open("config/selectors.yaml") as f:
        return yaml.safe_load(f)


async def main():
    load_dotenv()
    parser = argparse.ArgumentParser(description="Multi-item returns automation agent")
    parser.add_argument("--demo", action="store_true", help="build sample data and dry-run it")
    parser.add_argument("--dry-run", action="store_true", help="run without a live browser")
    parser.add_argument("--live", action="store_true", help="run against real Amazon/Flipkart")
    parser.add_argument("--xlsx", default=DEFAULT_XLSX)
    args = parser.parse_args()

    audit_log = AuditLog()

    if args.demo:
        build_sample_workbook(args.xlsx, SAMPLE_ROWS)
        print(f"Sample workbook written to {args.xlsx}")
        await orchestrator.run(args.xlsx, adapter_factory=None, audit_log=audit_log, dry_run=True)

    elif args.dry_run:
        await orchestrator.run(args.xlsx, adapter_factory=None, audit_log=audit_log, dry_run=True)

    elif args.live:
        selectors = _load_selectors()
        factory = await _live_adapter_factory(selectors, audit_log)
        await orchestrator.run(args.xlsx, adapter_factory=factory, audit_log=audit_log, dry_run=False)

    else:
        parser.print_help()
        return

    print(f"Audit log written to {audit_log.path}")
    audit_log.close()


if __name__ == "__main__":
    asyncio.run(main())
