# Returns Automation Agent

A browser automation agent that reads pending return tasks from Excel, places
returns on Amazon or Flipkart, and writes the outcome back per line item,
built against the assignment brief in `Sourcing return automation agent.pdf`.

## Quick start

```bash
pip install -r requirements.txt
playwright install chromium

python main.py --demo       # builds sample data/returns.xlsx and dry-runs it
python main.py --dry-run    # dry-runs an existing Excel file, no browser
python main.py --live       # real Amazon/Flipkart run, needs .env filled in
```

Run the test suite (no browser required, 10 tests, all passing):

```bash
python -m pytest tests/ -v
```

## What actually works right now vs. what's scaffolded

Being direct about this rather than implying more than what's true:

**Fully working and tested (`--demo` / `--dry-run` / `pytest`):**
- Excel read/write matching the spec's exact field schema (section 4)
- Order grouping and per-line-item processing
- Eligibility checking (return window) before any browser action
- Partial-success handling: verified with a unit test that reproduces the
  exact 3-item, 1-ineligible-item scenario from section 5
- Deterministic batch-vs-sequential flow detection (section 2), unit tested
  across single-seller, multi-seller, and split-shipment Amazon orders
- Resumable runs (only "To Do"/"In Progress" rows get re-processed)
- Structured JSON audit logging per run

**Scaffolded, needs a live session to finish and verify:**
- The actual Amazon/Flipkart CSS selectors in `config/selectors.yaml`.
  I wrote these against each platform's typical order/returns page
  structure, but Flipkart's login requires an OTP delivered by a phone
  call to a specific number (per the brief), which means the live path
  can't be exercised end-to-end without a human present for that one step.
  `main.py --live` pauses for that input rather than trying to fake around it.
- Stealth measures (`core/stealth.py`) are implemented and used by both
  adapters, but I haven't run them against Flipkart's live bot detection to
  confirm they hold up; that's an empirical question no amount of code
  review settles on its own.

I'd rather ship an honestly-scoped submission than claim a fully verified
live integration I can't actually prove in this environment.

## Architecture

```
main.py                  CLI entrypoint: --demo / --dry-run / --live
core/
  models.py               ReturnTask, OrderGroup, status enums
  excel_io.py              Schema-exact read/write, resumable by design
  flow_detector.py           Deterministic batch/sequential detection
  orchestrator.py             Main loop: grouping, retries, partial success
  stealth.py                  Human-like timing/typing/mouse movement
  audit_log.py                  Structured JSONL run log
adapters/
  base.py                        Abstract PlatformAdapter interface
  amazon.py, flipkart.py           One file per platform
config/
  selectors.yaml                    CSS selectors, kept out of Python
data/
  sample_data.py                     Fixtures for --demo
tests/                                Unit tests, no browser needed
```

## Design decisions (short version, see DESIGN.md for the full reasoning)

- **Adapter pattern, not a single monolithic script.** Amazon and Flipkart
  have completely different DOMs; a new platform should mean one new
  adapter file, not edits scattered through shared control flow.
- **Flow detection is a deterministic lookup, not an LLM call.** It's a
  property of the platform/order, not something that should vary run to
  run. Free, instant, and unit-testable without mocking anything.
- **Two failure types, handled differently.** "Out of window" is a normal
  outcome, recorded immediately, never retried. A page timeout or selector
  miss is retried with exponential backoff up to 3 attempts before it
  becomes "Needs human review". Conflating these means either retrying
  things that will never succeed or giving up on things that would have
  worked on attempt two.
- **Resumable by construction.** Only rows still "To Do"/"In Progress" are
  loaded each run, and every single line item's result is written to disk
  immediately, so a crash mid-run costs nothing already completed.
- **Selectors live in YAML, not Python.** These sites change their DOM on
  a normal release cadence; a broken selector should be a one-line config
  fix, not a code change and redeploy.

## Known limitations

- Selectors are representative, not verified against a live DOM snapshot
  taken today; retail sites update their markup often enough that this is
  true of any take-home submission claiming to be "production ready"
  without a live test account already in hand.
- Stealth measures reduce, not eliminate, the chance of bot detection.
  No client-side technique can promise otherwise.
- The Flipkart OTP-by-phone-call step is inherently manual; I built the
  seam (`_await_human_otp_entry`) rather than a fake workaround.
