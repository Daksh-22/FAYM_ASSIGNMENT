"""
Proves the section-5 requirement directly: in a 3-item order where one item
is out of window, the other two still get processed (dry-run: marked
PLACED) and the run does not abort or skip the whole order.
"""

import asyncio
import openpyxl
import pytest

from core.excel_io import build_sample_workbook, COLUMNS
from core import orchestrator
from data.sample_data import SAMPLE_ROWS


@pytest.mark.asyncio
async def test_partial_success_within_order(tmp_path):
    xlsx_path = str(tmp_path / "returns.xlsx")
    build_sample_workbook(xlsx_path, SAMPLE_ROWS)

    class FakeAuditLog:
        def event(self, **kwargs):
            pass

    await orchestrator.run(xlsx_path, adapter_factory=None, audit_log=FakeAuditLog(), dry_run=True)

    wb = openpyxl.load_workbook(xlsx_path)
    ws = wb.active
    header = [c.value for c in ws[1]]
    idx = {name: header.index(name) for name in COLUMNS}

    rows_by_order = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        rows_by_order.setdefault(row[idx["Order ID"]], []).append(row)

    od1003 = rows_by_order["OD1003"]
    assert len(od1003) == 3

    statuses = {row[idx["Product/SKU"]]: row[idx["Return status"]] for row in od1003}
    assert statuses["SKU-PHONE-CASE-A"] == "Placed"
    assert statuses["SKU-SCREEN-GUARD"] == "Out of window"   # the one ineligible item
    assert statuses["SKU-CHARGER-C"] == "Placed"

    task_statuses = {row[idx["Product/SKU"]]: row[idx["Task status"]] for row in od1003}
    # every item has a terminal task status: order is fully resolved even
    # though one item within it failed eligibility
    assert all(s == "Done" for s in task_statuses.values())
