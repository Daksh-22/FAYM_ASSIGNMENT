from datetime import date, timedelta
from core.models import ReturnTask


def _task(return_window_end):
    return ReturnTask(row_index=2, platform="Flipkart", order_id="OD1", product_sku="SKU1",
                       return_window_end=return_window_end)


def test_eligible_when_window_in_future():
    t = _task(date.today() + timedelta(days=3))
    assert t.is_eligible() is True


def test_ineligible_when_window_in_past():
    t = _task(date.today() - timedelta(days=1))
    assert t.is_eligible() is False


def test_eligible_on_exact_last_day():
    t = _task(date.today())
    assert t.is_eligible() is True


def test_eligible_when_window_unknown():
    t = _task(None)
    assert t.is_eligible() is True
