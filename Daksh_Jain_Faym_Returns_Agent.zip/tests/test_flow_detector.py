from core.flow_detector import detect_flow_model
from core.models import FlowModel


def test_flipkart_always_sequential():
    assert detect_flow_model("flipkart", []) == FlowModel.SEQUENTIAL
    assert detect_flow_model("Flipkart", [{"sku": "a"}, {"sku": "b"}]) == FlowModel.SEQUENTIAL


def test_amazon_single_seller_single_shipment_is_batch():
    items = [
        {"sku": "a", "seller_id": "S1", "shipment_id": "SH1"},
        {"sku": "b", "seller_id": "S1", "shipment_id": "SH1"},
    ]
    assert detect_flow_model("amazon", items) == FlowModel.BATCH


def test_amazon_multi_seller_is_sequential():
    items = [
        {"sku": "a", "seller_id": "S1", "shipment_id": "SH1"},
        {"sku": "b", "seller_id": "S2", "shipment_id": "SH2"},
    ]
    assert detect_flow_model("amazon", items) == FlowModel.SEQUENTIAL


def test_amazon_split_shipment_same_seller_is_sequential():
    items = [
        {"sku": "a", "seller_id": "S1", "shipment_id": "SH1"},
        {"sku": "b", "seller_id": "S1", "shipment_id": "SH2"},
    ]
    assert detect_flow_model("amazon", items) == FlowModel.SEQUENTIAL


def test_unknown_platform_defaults_to_sequential():
    assert detect_flow_model("myntra", [{"sku": "a"}]) == FlowModel.SEQUENTIAL
